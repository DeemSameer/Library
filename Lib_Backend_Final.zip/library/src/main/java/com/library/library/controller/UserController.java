package com.library.library.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.library.entity.Book;
import com.library.library.entity.Borrow;
import com.library.library.entity.Person;
import com.library.library.entity.User;
import com.library.library.service.BookService;
import com.library.library.service.BorrowService;
import com.library.library.service.PersonService;

@RestController
@RequestMapping("/userAPI")
@CrossOrigin
public class UserController {

	public UserController() {
	}

	@GetMapping("/getUserByIdOrUsername/{Id}/{userName}")
	public User getUserByIdOrUsername(@PathVariable int Id, @PathVariable String userName) {
		Person person=null;
		try {
			person = PersonService.findById(Id); 
		}catch(Exception ex) {
			person = PersonService.findByUserName(userName);
		}
		
		return (User)person;
	}

	@PostMapping("/createUser")
	public User createUser(@RequestBody User user) {
		PersonService.save(user);
		return user;
	}

	@PutMapping("/updateUser")
	public User updateUser(@RequestBody User user) {
		PersonService.save(user);
		return user;
	}
///////////////////////////////////CHANGE 
	@GetMapping("/getAllUsers")
	public List<User> getAllUsers() {
		return PersonService.findAllUsers();
	}

	@GetMapping("/getUser/{userId}")
	public User getUser(@PathVariable int userId) {
		User user = (User)PersonService.findById(userId);
		if (user == null) {
			throw new RuntimeException("book id not found - " + userId);
		}
		return user;
	}

	@DeleteMapping("/deleteUser/{userId}")
	public String deleteUser(@PathVariable int userId) {

		User user = (User)PersonService.findById(userId);

		// throw exception if null

		if (user == null) {
			throw new RuntimeException("user id not found - " + userId);
		}

		
		Borrow[] temp = BorrowService.findBorrowByPerson(user); 
		for(Borrow b:temp) {
			BorrowService.deleteById(b.getId());
			Book tempBook = b.getBook();
			int q = b.getBook().getQuantity(); 
			tempBook.setQuantity(q+1);
			int bq = b.getBook().getBorrowedQuantity(); 
			tempBook.setBorrowedQuantity(bq-1);
			BookService.save(tempBook);
		}
		PersonService.deleteById(userId);
		return "Deleted user id - " + userId;
	}

}
