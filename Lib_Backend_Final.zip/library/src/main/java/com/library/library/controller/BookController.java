package com.library.library.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.token.TokenService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.library.entity.Book;
import com.library.library.service.BookService;;


@RestController
@RequestMapping("/booksAPI")
@CrossOrigin(origins = "http://localhost:4200")  
public class BookController {
	
//	 @Autowired  
//	 private TokenService tokenService;

	public BookController() {
	}
	
	
	@PostMapping("/addBook")
	public Book addBook(@RequestBody Book Book) {
		BookService.save(Book);
		return Book;
	}

	@PutMapping("/updateBook")
	public Book updateBook(@RequestBody Book Book) {
		BookService.save(Book);
		return Book;
	}

	@GetMapping("/books")
	public List<Book> getAllBooks() {
		
		return BookService.findAll();  

	}


	@GetMapping("/books/{BookId}")
	public Book getBook(@PathVariable int BookId) {
		Book Book = BookService.findById(BookId);
		if (Book == null) {
			throw new RuntimeException("Book id not found - " + BookId);
		}
		return Book;
	}

	@DeleteMapping("/deleteBook/{BookId}")
	public String deleteBook(@PathVariable int BookId) {

		Book Book = BookService.findById(BookId);

		// throw exception if null

		if (Book == null) {
			throw new RuntimeException("Book id not found - " + BookId);
		}

		BookService.deleteById(BookId);

		return "Deleted Book id - " + BookId;
	}

	@GetMapping("/books/{BookId}/{name}/{authorName}")
	public Book getBookByNameOrIdOrAuthorname(@PathVariable int BookId, @PathVariable String name,
			@PathVariable String authorName) {
		Book Book = BookService.getBookByNameOrIdOrAuthorname( BookId,  name,  authorName); 
		
		return Book;
	}

	@PostMapping("/addBooks")
	public List<Book> addBooks(@RequestBody List<Book> Books) {
		List<Book> tempBooks = new ArrayList<Book>();
		for (Book b : Books) {
			BookService.save(b);
			tempBooks.add(b);
		}
		return tempBooks;
	}

}
