package com.library.library.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Book")
public class Book {
	@Id
	@Column(name = "id")
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "ID_SEQ")
	private int id; 
	@Column(name = "title")
	private String title; 
	@Column(name = "author_name")
	private String authorName; 
	@Column(name = "quantity")
	private int quantity; 
	@Column(name = "borrowedQuantity")
	private int borrowedQuantity; 
	public Book() {
		
	}

	public Book(String title, String authorName, int quantity) {
		super();
		this.title = title;
		this.authorName = authorName;
		this.quantity = quantity;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getBorrowedQuantity() {
		return borrowedQuantity;
	}

	public void setBorrowedQuantity(int borrowedQuantity) {
		this.borrowedQuantity = borrowedQuantity;
	}

	@Override
	public String toString() {
		return "Book [id=" + id + ", title=" + title + ", authorName=" + authorName + ", quantity=" + quantity
				+ ", borrowedQuantity=" + borrowedQuantity + "]";
	}

//	@Override
//	public String toString() {
//		return "book [id=" + id + ", title=" + title + ", authorName=" + authorName + ", quantity=" + quantity + "]";
//	}
	
	
	
}
