package com.library.library.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.library.entity.Person;
import com.library.library.entity.Book;
import com.library.library.entity.Borrow;
import com.library.library.entity.Librarian;
import com.library.library.service.BookService;
import com.library.library.service.BorrowService;
import com.library.library.service.PersonService;

@RestController
@RequestMapping("/librarianAPI")
public class LibrarianController {

	public LibrarianController() {
	}

	@GetMapping("/getLibrarianByIdOrLibrarianname/{Id}/{userName}")
	public Librarian getLibrarianByIdOrLibrarianname(@PathVariable int Id, @PathVariable String userName) {
		Person person =null; 
		try {
			person = PersonService.findById(Id); 
		}catch(Exception ex) {
			person = PersonService.findByUserName(userName);
		}
		
		return (Librarian)person;
	}

	@PostMapping("/createLibrarian")
	public Librarian createLibrarian(@RequestBody Librarian user) {
		PersonService.save(user);
		return user;
	}

	@PutMapping("/updateLibrarian")
	public Librarian updateLibrarian(@RequestBody Librarian user) {
		PersonService.save(user);
		return user;
	}
///////////////////////////////////CHANGE 
	@GetMapping("/getAllLibrarians")
	public List<Librarian> getAllLibrarians() {
		return PersonService.findAllLibrarians();
	}

	@GetMapping("/getLibrarian/{userId}")
	public Librarian getLibrarian(@PathVariable int userId) {
		Librarian user = (Librarian)PersonService.findById(userId);
		if (user == null) {
			throw new RuntimeException("Librarian id not found - " + userId);
		}
		return user;
	}

	@DeleteMapping("/deleteLibrarian/{libId}")
	public String deleteLibrarian(@PathVariable int libId) {

		Librarian librarian = (Librarian)PersonService.findById(libId);
		// throw exception if null

		if (librarian == null) {
			throw new RuntimeException("book id not found - " + libId);
		}

		Borrow[] temp = BorrowService.findBorrowByPerson(librarian); 
		for(Borrow b:temp) {
			BorrowService.deleteById(b.getId());
			Book tempBook = b.getBook();
			int q = b.getBook().getQuantity(); 
			tempBook.setQuantity(q+1);
			int bq = b.getBook().getBorrowedQuantity(); 
			tempBook.setBorrowedQuantity(bq-1);
			BookService.save(tempBook);
		} 
		PersonService.deleteById(libId);

		return "Deleted user id - " + libId;
	}
	
	
}
