package com.library.library.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.library.library.entity.Librarian;
import com.library.library.entity.Person;
import com.library.library.entity.User;

public interface LibrarianRepository extends JpaRepository<Librarian, Integer>{
	
//	@Query("SELECT p FROM Person p WHERE p.username = ?1")
	public Librarian findByUsername(String UserName); 
 
}
