package com.library.library.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="borrow")
public class Borrow {
	@Id
	@Column(name = "id")
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "ID_SEQ")
	private int id; 
	
	@ManyToOne(cascade= {CascadeType.MERGE,CascadeType.REFRESH})
	@JoinColumn(name="book_id")
	private Book book;
	@ManyToOne(cascade= {CascadeType.MERGE,CascadeType.REFRESH})
	@JoinColumn(name="person_id")
	private Person person;
	
public Borrow() {
		
	}

	public Borrow(Book book, Person person) {
		super();
		this.book = book;
		this.person = person;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}	

}
