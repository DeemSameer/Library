package com.library.library.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.library.dao.BookRepository;
import com.library.library.dao.BorrowRepository;
import com.library.library.dao.PersonRepository;
import com.library.library.entity.Book;
import com.library.library.entity.Borrow;
import com.library.library.entity.Person;


import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

@Service
public class BorrowService {


	private static BorrowRepository borrowRepository;
	private static BookRepository bookRepository;
	private static PersonRepository personRepository; 


	@Autowired()
	public BorrowService(BorrowRepository borrowRepository,
			BookRepository bookRepository,
			PersonRepository personRepository) {
		this.borrowRepository = borrowRepository;
		this.bookRepository=bookRepository; 
		this.personRepository = personRepository; 
	}

	public static List<Borrow> findAll() {
		// TODO Auto-generated method stub
		return borrowRepository.findAll();
	}
	
	
	public static List<Book> findAllGroupedByBookId(){
		List<Borrow> b=  borrowRepository.findAll(); 
		Map<Book, List<Borrow>> booklistGrouped = b.stream().collect(Collectors.groupingBy(w -> w.getBook()));
		List<Book> valueList  = new ArrayList<Book>(booklistGrouped.keySet());
		return valueList; 
	}

	public static Borrow findById(int Id) {
		Optional<Borrow> result = borrowRepository.findById(Id);
		Borrow Borrow = null;
		if (result != null)
			Borrow = result.get();
		return Borrow;
	}

	public static void save(Borrow borrow) {
		//Check if the person already borrowed this book. 
		if(findByBookIdAndPersonId(borrow.getBook(), borrow.getPerson())) {
			return; 
		}
		bookRepository.save(borrow.getBook()); 
//		personRepository.save(borrow.getPerson()); 
		borrowRepository.save(borrow);

	}
	
	public static boolean findByBookIdAndPersonId(Book book, Person person) {
		boolean flag = false; 
		if (borrowRepository.findByBookIdAndPersonId(book, person)!=null) {
			flag=true; 
		}
		return flag ; 
	}

	public static void deleteById(int Id) {
		borrowRepository.deleteById(Id);
	}

	public static Borrow[] findBorrowByPerson(Person person) {
		return borrowRepository.findBorrowByPerson(person);
	}

	public static Borrow[] findBorrowByBook(Book book) {
		return borrowRepository.findBorrowByBook(book);
	}

	
}
