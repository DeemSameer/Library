package com.library.library.entity;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.Table;
import javax.persistence.InheritanceType;
import javax.persistence.SequenceGenerator; 

//Parent of User and Librarian 
@Entity
@Table(name = "person")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="person_role", 
discriminatorType = DiscriminatorType.STRING)
public class Person {
	@Id
	@Column(name = "id")
//	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "id_Sequence")
	@SequenceGenerator(name = "id_Sequence", sequenceName = "ID_SEQ")
	private int id; 
	@Column(name = "username")
	private String username;
	@Column(name = "name")
	private String name;
	@Column(name = "mail")
	private String mail;
	@Column(name = "phone_number")
	private String phoneNumber;
	@Column(name = "password")
	private String password;

	
	@Column(name = "person_role", insertable = false, updatable = false)
    private String person_role;


	public Person() {

	}

	public Person(String username, String password) {
		this.username = username;
		this.password = password;
	}
	
	public Person(String username, String password, String name, String mail, String phoneNumber) {
		this.username = username;
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPerson_role() {
		return person_role;
	}

	public void setPerson_role(String person_role) {
		this.person_role = person_role;
	}

	public String toString() {
		return "User [id=" + id + ", username=" + username + ", name=" + name + ", mail=" + mail + ", phoneNumber="
				+ phoneNumber + ", password=" + password 
				+ "]";
	}
}
