package com.library.library.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


@Entity
@DiscriminatorValue("user")
public class User extends Person {
	
	public User() {
		super();
	}

	
}
