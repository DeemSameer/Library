package com.library.library.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.library.dao.LibrarianRepository;
import com.library.library.dao.PersonRepository;
import com.library.library.dao.UserRepository;
import com.library.library.entity.Librarian;
import com.library.library.entity.Person;
import com.library.library.entity.User;
@Service
public class PersonService {
	
	private static PersonRepository personRepository; 
	private static UserRepository userRepository; 
	private static LibrarianRepository librarianRepository; 
	
	@Autowired()
	public PersonService(PersonRepository personRepository,
			UserRepository userRepository,
			LibrarianRepository librarianRepository) {
		this.personRepository = personRepository;
		this.userRepository= userRepository; 
		this.librarianRepository=librarianRepository; 
	}
	
	public static List<Person> findAll() {
		// TODO Auto-generated method stub
		return personRepository.findAll();
	}

	 
	public static Person findById(int Id) {
		Optional<Person> result = personRepository.findById(Id);
		Person Person = null;
		if (result != null)
			Person = result.get();
		return Person;
	}

	 
	public static Person save(Person person) {
		Person temp = null; 
		try {
			temp = findByUserName(person.getUsername());
		}catch(Exception ex) {
			
		}
		if(temp!=null)
			return null; 
		if(person.getPerson_role().equals("user")) {
			User user = new User();
			user.setId(person.getId());
			user.setName(person.getName());
			user.setMail(person.getMail());
			user.setPassword(person.getPassword());
			user.setPerson_role(person.getPerson_role());
			user.setPhoneNumber(person.getPhoneNumber());
			user.setUsername(person.getUsername());
			return userRepository.save(user); 
		}
		if(person.getPerson_role().equals("librarian")) {
			Librarian librarian = new Librarian();
			librarian.setId(person.getId());
			librarian.setName(person.getName());
			librarian.setMail(person.getMail());
			librarian.setPassword(person.getPassword());
			librarian.setPerson_role(person.getPerson_role());
			librarian.setPhoneNumber(person.getPhoneNumber());
			librarian.setUsername(person.getUsername());
			return librarianRepository.save(librarian); 
		}
		return personRepository.save(person);
	}

	 
	public static void deleteById(int Id) {
		personRepository.deleteById(Id);
	}

	public static Person findByUserName(String userName) {
		return personRepository.findByUsername(userName);
	}

	
	//TBI
	public static List<User> findAllUsers() {
		
		return userRepository.findAll();
	}

	public static List<Librarian> findAllLibrarians() {
		// TODO Auto-generated method stub
		return librarianRepository.findAll();
	}

	 
	
}
