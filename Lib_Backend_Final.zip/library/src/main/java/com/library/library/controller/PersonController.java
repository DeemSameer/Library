package com.library.library.controller;

import java.security.Principal;
import java.util.Base64;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.library.library.service.PersonService;

import com.library.library.entity.Person;

@RestController
@CrossOrigin
public class PersonController {

//	@Autowired
//	private PasswordEncoder passwordEncoder;
	
	@RequestMapping("/login")
    public Person login(@RequestBody Person user) {
		Person tempUser = PersonService.findByUserName(user.getUsername()); 
        if(tempUser==null)
        	return null; 
        String encoded = new BCryptPasswordEncoder().encode(user.getPassword());
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        boolean isPasswordMatch = passwordEncoder.matches(user.getPassword(), tempUser.getPassword());
        if(!isPasswordMatch)
        	return null; 
        return tempUser;         
    }
	
	@RequestMapping("/register")
    public Person register(@RequestBody Person user) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		Person alreadyExisit = PersonService.findByUserName(user.getUsername()); 

		if(user==null||alreadyExisit!=null)
			return null; 
	    user.setPassword(passwordEncoder.encode(user.getPassword()));

		Person tempUser = PersonService.save(user); 
        if(tempUser==null)
        	return null; 

        return tempUser;         
    }
	
    @RequestMapping("/user")
    public Principal user(HttpServletRequest request) {
        String authToken = request.getHeader("Authorization")
          .substring("Basic".length()).trim();
        return () ->  new String(Base64.getDecoder()
          .decode(authToken)).split(":")[0];
    }
}
