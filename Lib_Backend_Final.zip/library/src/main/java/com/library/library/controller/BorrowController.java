package com.library.library.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.library.entity.Book;
import com.library.library.entity.Borrow;
import com.library.library.entity.Person;
import com.library.library.service.BookService;
import com.library.library.service.BorrowService;
import com.library.library.service.PersonService;

@RequestMapping("/borrowAPI")
@RestController
@CrossOrigin
public class BorrowController {

	public BorrowController() {	
	}

	@PostMapping("/addborrow")
	public Borrow addborrow(@RequestBody Borrow Borrow) {
		BorrowService.save(Borrow);
		return Borrow;
	}

	@PutMapping("/updateborrow")
	public Borrow updateborrow(@RequestBody Borrow Borrow) {
		BorrowService.save(Borrow);
		return Borrow;
	}

	@GetMapping("/borrows")
	public List<Borrow> getAllBorrows() {
		return BorrowService.findAll();
	}
	
	@GetMapping("/BookBorrows")
	public List<Book> getAllBorrowsGroupedBy() {
		return BorrowService.findAllGroupedByBookId();
	}
	
	

	@GetMapping("/borrows/{borrowId}")
	public Borrow getborrow(@PathVariable int borrowId) {
		Borrow Borrow = BorrowService.findById(borrowId);
		if (Borrow == null) {
			throw new RuntimeException("Borrow id not found - " + borrowId);
		}
		return Borrow;
	}

	@DeleteMapping("/deleteBorrow/{borrowId}")
	public String deleteBorrow(@PathVariable int borrowId) {

		Borrow Borrow = BorrowService.findById(borrowId);

		// throw exception if null

		if (Borrow == null) {
			throw new RuntimeException("Borrow id not found - " + borrowId);
		}

		BorrowService.deleteById(borrowId);

		return "Deleted Borrow id - " + borrowId;
	}

	@GetMapping("/getBorrowByIdOrUserIdOrBookId/{borrowId}/{userId}/{bookId}")
	public Borrow[] getBorrowByIdOrUserIdOrBookId(@PathVariable int borrowId, @PathVariable int userId,
			@PathVariable int bookId) {

		Borrow[] borrow = null;

		try {
			borrow[0] = BorrowService.findById(borrowId);

		} catch (Exception ex) {
			try {
				Person person = PersonService.findById(userId);
				borrow = BorrowService.findBorrowByPerson(person);
			} catch (Exception ex1) {
				try {
					Book book = BookService.findById(bookId); 
					borrow = BorrowService.findBorrowByBook(book);	
				}catch (Exception ex2) {
					return null; 
				}
				
			}
		}

		return borrow;
		
	}
	@GetMapping("/getBorrowByUserId/{id}")
	public Borrow[] getBorrowByUserId(@PathVariable int id) {

		Borrow[] borrow = null;

		
			try {
				Person person = PersonService.findById(id);
				borrow = BorrowService.findBorrowByPerson(person);
			} catch (Exception ex1) {
				
				
			}
		

		return borrow;
		
	}
}
