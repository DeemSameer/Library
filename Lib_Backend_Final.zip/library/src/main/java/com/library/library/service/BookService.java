package com.library.library.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.library.dao.BookRepository;
import com.library.library.entity.Book;
@Service
public class BookService {

	private static BookRepository bookRepository; 
	
	@Autowired()
	public BookService(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}
	 
	public static List<Book> findAll() {
		// TODO Auto-generated method stub
		return bookRepository.findAll();
	}

	 
	public static Book findById(int Id) {
		Optional<Book> result = bookRepository.findById(Id);
		Book Book = null;
		if (result != null)
			Book = result.get();
		return Book;
	}

	 
	public static void save(Book Book) {
		bookRepository.save(Book);
	}

	 
	public static void deleteById(int Id) {
		bookRepository.deleteById(Id);
	}

	 
	public static Book findBookByName(String name) {
		return bookRepository.findByTitle(name);
	}

	 
	public static Book findBookByAuthorName(String authorName) {
		return bookRepository.findByAuthorName(authorName);
	}


	 
	public static Book getBookByNameOrIdOrAuthorname(int BookId, String name, String authorName) {
		Book Book = findById(BookId);
		if (Book == null) {
//			throw new RuntimeException("Book id not found - " + BookId);
			Book = findBookByName(name);
			if (Book == null) {
				Book = findBookByAuthorName(authorName);
			}
		}
		return Book; 
	}
}
