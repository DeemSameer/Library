package com.library.library.entity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue("librarian")
public class Librarian extends Person{
	
	public Librarian() {
		super();
	}
	
}
