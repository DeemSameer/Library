package com.library.library.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.library.library.entity.Book;
import com.library.library.entity.Borrow;
import com.library.library.entity.Person;

public interface BorrowRepository extends JpaRepository<Borrow, Integer>{
	
	public Borrow[] findBorrowByPerson(Person person);
	public Borrow[] findBorrowByBook(Book book);
	@Query("SELECT b from Borrow b where b.book=?1 AND b.person=?2")
	public Borrow findByBookIdAndPersonId(Book book, Person person);
//	@Query("SELECT b from Borrow b GROUP BY b.book")
//	@Query("SELECT b.book from Borrow b GROUP BY b.book")
//	@Query(value = "SELECT * FROM Borrow GROUP BY book_id",  nativeQuery = true)
//	@Query(value = "SELECT borrow.book_id,book.title, COUNT(*) FROM borrow  INNER JOIN book ON book.id = borrow.book_id GROUP BY book_id,book.title",  nativeQuery = true)
//	@Query(value = "SELECT b.book_id, b.id,b.person_id from Borrow b group by b.book_id,b.id,b.person_id")
//	public List<Borrow> findAllGroupedByBookId();

}
